#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <windows.h>
using namespace std;

const int size_of_table = 29;
string sub_menu="\t\t\t\t";
HANDLE  hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
class shopping_list_class{
private:
    string item_name;
    float item_price;
public:
    shopping_list_class() {item_name = "Something"; next = nullptr;}
    void set_name(string a) {item_name = a;}
    void set_price (float a) {item_price = a;}
    string get_name() {return item_name;}
    float get_price () {return item_price;}
    shopping_list_class* next;
};

void title(string a){
    system("cls");
    cout << endl;
    SetConsoleTextAttribute(hConsole, 3);
    cout << "                                   ....         .-:::-.                                                 ....   " << endl;
    cout << "                -/////`           .++++-      -/++++++++-                                              -++++.  " << endl;
    cout << "               .++++++/           .++++-     -++++:--:/:                                               -++++.  " << endl;
    cout << "              `/+++++++-          .++++-     /+++/                                                     -++++.  " << endl;
    cout << "              :+++//++++.         .++++-     /+++/                                                     -++++.  " << endl;
    cout << "             -++++-`/+++/`        .++++-     /+++/                                                     -++++.  " << endl;
    cout << "            `/+++:  .++++:        .++++-  ://+++++/////  ://:  `-://.    .-://////:-`        `.-://///:/++++.  " << endl;
    SetConsoleTextAttribute(hConsole, 9);
    cout << "            /+++/`   :++++-       .++++-  /++++++++++++  /+++-:/++++:  ./++++///++++/-      -/++++++++++++++.  " << endl;
    cout << "           -++++.    `/+++/`      .++++-  ```/+++/`````  /++++++/:--. -++++:.````:++++-   `:++++/-.```.:++++.  " << endl;
    cout << "          .++++/......:++++/      .++++-     /+++/       /++++:.     .++++:```````:++++`  /++++-       -++++.  " << endl;
    cout << "         `/+++++++++++++++++-     .++++-     /+++/       /++++`      :++++/////////++++. -++++-        -++++.  " << endl;
    SetConsoleTextAttribute(hConsole, 13);
    cout << "         :++++///////////++++.    .++++-     /+++/       /++++       :++++////////////-` :++++.        -++++.  " << endl;
    cout << "        .++++:          .++++/`   .++++-     /+++/       /++++       :++++.```````````   -++++-        -++++.  " << endl;
    cout << "       `/+++/            -++++:   .++++-     /+++/       /++++       .++++:`        ``   `++++/`      `-++++.  " << endl;cout << "       /++++.             /++++.  .++++-     /+++/       /++++        -++++/-.....-://`   -++++/:....:/+++++.  " << endl;
    SetConsoleTextAttribute(hConsole, 5);
    cout << "      -++++-              `++++/  .++++-     /+++/       /++++         ./++++++++++++/-    ./++++++++++//+++.  " << endl;
    cout << "     `::::-                -::::- `::::.     -:::-       -::::           `-://///::-.`       .-:////:-` `:::`  " << endl;
    SetConsoleTextAttribute(hConsole, 7);
    cout << endl << endl << "\t\t\t\t\t\t" << a << endl << endl;
}

int string_to_int(string a){
    int sum=0;
    int b[a.size()];
    for (int i=0; i<a.size(); i++)
        b[i] = a[i];
    for (int i=0; i<a.size(); i++)
        sum += b[i];
    return sum;
}

void pause_menu(){
    SetConsoleTextAttribute(hConsole, 0);
    system("pause");
    SetConsoleTextAttribute(hConsole, 7);
}

void add_menu(shopping_list_class* (&y), int a){
    float budget = a, current=0, w;
    string q;
    int counter=0;

    while (y->next != nullptr)
        y = y->next;

    do {
        title ("Adding items to list");
        if (counter == 1)
            cout << sub_menu << "\"" <<  q << "\"" << " has been added to the list."<< endl << endl;
        cout << sub_menu << "Item name or type \"exit\" : ";
        cin >> q;
        if (q == "exit")
            break;
        cout << sub_menu << "Estimated price of " << q << ": RM ";
        cin >> w;
        current += w;

        if (current > budget){
            cout << sub_menu << "Exceeded budget(" << budget << "), item not saved" << endl << endl;
            cout << sub_menu << "press enter to go back" << endl;
            pause_menu();
        }
        else{
            shopping_list_class* m = new shopping_list_class();
            m->set_name(q);
            m->set_price(w);

            y->next = m;
            y=y->next;
            counter=1;
        }
    }while (q != "exit");
}

int search_hash_table(shopping_list_class x[size_of_table], string a){
    int pos = string_to_int(a) % size_of_table;
    while (pos > size_of_table)
        pos = pos%size_of_table + pos/size_of_table;
    while (x[pos].get_name() != a){
        pos++;
        if (pos == size_of_table)
            break;
    }
    if (pos == size_of_table)
        return 99;
    else
        return pos;
}

void view_linked_list(shopping_list_class* x){
    cout << sub_menu << "List : " << x->get_name() << endl;
    cout << sub_menu << "Budget : RM " << x->get_price() << endl;
    float total = 0;
    int counter=1;
    x = x->next;
    cout << endl;
    while (x != nullptr){
        cout << "\t" << sub_menu << counter << ". " << x->get_name() << " @ RM " << x->get_price() << endl;
        counter++;
        total += x->get_price();
        x = x->next;
    }
    cout << endl;
    cout << sub_menu << "Total estimated cost : RM" << total << endl;
}

void sorting_2 (shopping_list_class* (&y), int n){
    do {
        if (y->next->get_name()[n] > y->next->next->get_name()[n]){
            shopping_list_class* y_2 = y->next;
            y->next = y->next->next;
            y_2->next = y_2->next->next;
            y=y->next;
            y->next = y_2;
        }
        else
            sorting_2(y, (n++));
    }while (n<sizeof(y->next->get_name()) && n<sizeof(y->next->next->get_name()));
}

void head_insert(shopping_list_class (&x) [size_of_table], shopping_list_class* (&a), string b){
    int pos = (string_to_int(b) % size_of_table);
    while (pos > size_of_table)
        pos = pos%size_of_table + pos/size_of_table;
    while (x[pos].get_name() != "Something"){
        pos++;
        if (pos == size_of_table)
            break;
    }
    if (pos == size_of_table)
        cout << "Table is full\n";
    else
        x[pos] = *a;
}

int choose_list(shopping_list_class x[size_of_table]){
    string a;
    cout << sub_menu << "Name of list : ";
    cin >> a;
    return search_hash_table(x, a);
}

int main(){
    int choice=0;
    float input_float=0;
    shopping_list_class hash_table [size_of_table];
    string input;

    ifstream file_read;
    ofstream file_write;

    file_read.open("data.txt");

    while (!file_read.eof()){
        stringstream ss;
        string input2;
        shopping_list_class* head = new shopping_list_class();
        shopping_list_class* cursor = head;

        file_read >> input >> input2;
        head->set_name(input);
        ss << input2;
        ss >> input_float;
        head->set_price(input_float);
        input2.clear();
        input_float=0;
        while(file_read >> input >> input2){
            ss = stringstream();
            if (input != "end_of_list"){
                shopping_list_class* x = new shopping_list_class();
                ss << input2;
                ss >> input_float;
                x->set_name(input);
                x->set_price(input_float);
                cursor->next = x;
                cursor=cursor->next;
            }
            else
                break;
        }
        if ((head->get_name() != "end_of_list") && (head->get_name() != ""))
            head_insert(hash_table, head, (head->get_name()));
    }
    file_read.close();

    do {
        title("What would you like to do today?");
        cout << sub_menu << "1. Create new list" << endl;
        cout << sub_menu << "2. Add item to list" << endl;
        cout << sub_menu << "3. Edit/Delete List/Item(s) in list" << endl;
        cout << sub_menu << "4. View items in list" << endl;
        cout << sub_menu << "5. Exit program" << endl << endl;
        cout << sub_menu << "Your choice [1-5]: ";
        cin >> choice;

        switch(choice){
            case 1:{
                title("Creating a new list");
                cout << endl;
                cout << "\t\t\tLet's give this list a name : ";
                cin >> input;

                shopping_list_class* head = new shopping_list_class();
                head->set_name(input);

                title("Creating a new list");
                cout << endl << sub_menu << "Enter a budget for this list" << endl << endl;
                cout << "\t\t\t\t\tRM : ";
                cin >> input_float;
                head->set_price(input_float);

                title("Creating a new list");
                cout << sub_menu << "Now let's add some items to this list" << endl;
                cout << sub_menu << "\tPress enter to continue" << endl;
                cout << sub_menu << "Item name or type \"exit\" : ";
                shopping_list_class* temp = new shopping_list_class();
                head -> next = temp;
                cin >> input;
                temp->set_name(input);
                cout << sub_menu << "Estimated price of " << input << ": RM ";
                cin >> input_float;
                temp->set_price(input_float);
                head_insert(hash_table, head, head->get_name());
                add_menu(temp, head->get_price());
                break;
            }
            case 2:{
                int temp = choose_list(hash_table);
                if (temp != 99){
                    shopping_list_class* temp_ptr = &hash_table[temp];
                    add_menu(temp_ptr, temp_ptr->get_price());
                }
                else
                    cout << sub_menu << "No such list is found" << endl;
                break;
            }
            case 3:{
                int choice1=0;
                title("Edit/Delete List/Items(s) in List");
                cout << sub_menu << "1. Edit/Delete Items in List\n";
                cout << sub_menu << "2. Delete List\n";
                cout << sub_menu << "3. Change list budget\n";
                cout << sub_menu << "4. Exit to main menu\n" << endl;
                cout << sub_menu << "Your choice [1-4]: ";
                cin >> choice1;
                int temp = choose_list(hash_table);
                if (temp != 99){
                    while (choice1 != 4){
                        switch (choice1){
                            case 1:{
                                title("Edit/Delete Items(s) in List");
                                shopping_list_class* temp_ptr = &hash_table[temp];
                                view_linked_list(temp_ptr);
                                cout << endl << endl;
                                cout << sub_menu << "Which item would you like to remove/edit ?\n";
                                cout << sub_menu << "Name : ";
                                cin >> input;
                                title("Edit/Delete Items(s) in List");
                                cout << sub_menu << "1. Edit item details\n";
                                cout << sub_menu << "2. Delete item\n";
                                cout << sub_menu << "3. Exit to main menu\n" << endl;
                                cout << "\t\t\tYour choice [1-3]: ";
                                int choice2;
                                cin >> choice2;

                                while (choice2 != 3){
                                    switch (choice2){
                                        case 1:{
                                            int choice3;
                                            do {
                                                temp_ptr = &hash_table[temp];
                                                while (temp_ptr->get_name() != input)
                                                    temp_ptr = temp_ptr->next;

                                                view_linked_list(&hash_table[temp]);
                                                title("Editing Items(s) in List");
                                                cout << sub_menu << "1. Edit name\n";
                                                cout << sub_menu << "2. Edit price\n";
                                                cout << sub_menu << "3. Exit\n" << endl;
                                                cout << "\t\t\tYour choice [1-3]: ";
                                                cin >> choice3;
                                                while (choice3 != 3)
                                                {
                                                    switch (choice3){
                                                        case 1:{
                                                            title("Editing Item in List");
                                                            cout << sub_menu << "Enter new name : ";
                                                            cin >> input;
                                                            temp_ptr->set_name(input);
                                                            break;
                                                        }
                                                        case 2:{
                                                            title("Editing Item in List");
                                                            cout << sub_menu << "Enter new price : ";
                                                            cin >> input_float;
                                                            temp_ptr->set_price(input_float);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }while(choice3 != 3);
                                            break;
                                        }
                                        case 2:{
                                            shopping_list_class* temp_node = &hash_table[temp];
                                            temp_node = temp_node->next;
                                            int counter=1;

                                            while (temp_node->get_name() != input){
                                                counter++;
                                                temp_node = temp_node->next;
                                            }
                                            temp_node = &hash_table[temp];
                                            temp_node = temp_node->next;
                                            for (int i=1; i<counter-1; i++)
                                                temp_node = temp_node->next;
                                            temp_node->next = (temp_node->next)->next;
                                            title("Editing Items(s) in List");
                                            cout << sub_menu << "Item has been deleted\n" << endl;
                                            cout << sub_menu << "Press enter to continue";
                                            pause_menu();
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                            case 2:{
                                title("Deleting List");
                                hash_table[temp].set_name("Something");
                                cout << sub_menu << "List has been deleted\n";
                                pause_menu();
                                break;
                            }
                            case 3:{
                                title("Editing List Budget");
                                cout << sub_menu << "Current list budget : RM " << hash_table[temp].get_price() << endl;
                                cout << sub_menu << "Enter new budget or type \"cancel\" to cancel" << endl;
                                cout << "RM : ";
                                cin >> input;

                                if ((input != "cancel") || (input != "Cancel")){
                                    stringstream ss;
                                    ss << input;
                                    ss >> input_float;
                                    hash_table[temp].set_price(input_float);
                                }
                                break;
                            }
                    }
                    }
                }
                else
                    cout << sub_menu << "No such list is found\n";
                break;
            }
            case 4:{
                cout << sub_menu << "Choose a list : ";
                cin >> input;
                int temp = search_hash_table(hash_table, input);

                if (temp != 99){
                    shopping_list_class* temp_ptr = &hash_table[temp];

                    do {
                        if (temp_ptr->next == nullptr || temp_ptr->next->next == nullptr)
                            break;

                        else if (temp_ptr->next->get_name()[0] > temp_ptr->next->next->get_name()[0]){
                            shopping_list_class* x_2 = temp_ptr->next;
                            temp_ptr->next = temp_ptr->next->next;
                            x_2->next = x_2->next->next;
                            temp_ptr=temp_ptr->next;
                            temp_ptr->next = x_2;
                        }

                        else if (temp_ptr->next->get_name()[0] < temp_ptr->next->next->get_name()[0])
                            temp_ptr = temp_ptr->next;

                        else if (temp_ptr->next->get_name()[0] == temp_ptr->next->next->get_name()[0])
                            sorting_2(temp_ptr, (1));

                    }while((temp_ptr->next != nullptr) && (temp_ptr->next->next != nullptr));

                    title("Viewing list");
                    temp_ptr = &( hash_table[temp] );
                    view_linked_list(temp_ptr);
                    cout << endl << sub_menu << "Press enter to continue" << endl;
                    pause_menu();
                }
                else{
                    cout << sub_menu << "No such list is found" << endl;
                    cout << endl << sub_menu << "Press enter to continue" << endl;
                    pause_menu();
                }
                break;
            }
        }
    }while (choice != 5);

    title("Exiting Program...");
    cout << sub_menu << "Thank you and have a nice day" << endl;
    SetConsoleTextAttribute(hConsole, 0);

    file_write.open("data.txt", ios::trunc);
    for (int i=0; i<size_of_table; i++){
        if (hash_table[i].get_name()!= "Something"){
            shopping_list_class* temp_ptr = &hash_table[i];
            while (temp_ptr != nullptr){
                stringstream ss;
                ss<<temp_ptr->get_price();
                file_write  << temp_ptr->get_name() << " " << ss.str() << endl;
                pause_menu();
                temp_ptr = temp_ptr->next;
            }
            file_write << "end_of_list 999" << endl;
        }
    }
    file_write.close();
    return 0;
}
